﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestePJSII
{
    public class dbConnect
    {
        public String strConn = "Data Source=NT-01923\\TCC;Initial Catalog=PJS_TESTE;Persist Security Info=True;User ID=sa;Password=Tcc2018";
    }
}