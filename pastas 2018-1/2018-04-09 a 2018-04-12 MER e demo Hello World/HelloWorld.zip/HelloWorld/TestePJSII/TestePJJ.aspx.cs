﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace TestePJSII
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conexao = new SqlConnection();
            dbConnect strConn = new dbConnect();
            conexao.ConnectionString = strConn.strConn;
            SqlCommand comando = new SqlCommand();
            comando.CommandText = "select teste from Teste where id = " + Convert.ToInt32(consultaTXT.Text);
            string retorno = "";
            try
            {
                conexao.Open();
                comando.Connection = conexao;
                SqlDataReader reader = comando.ExecuteReader();
                if (reader.Read()) {
                    retorno = reader["teste"].ToString();
                }
                labelTeste.Text = "Seu teste foi um sucesso! Valor retornado: " + retorno;
            }
            catch (Exception ex)
            {
                labelTeste.Text = "Erro: " + ex.Message;
            }
        }
    }
}